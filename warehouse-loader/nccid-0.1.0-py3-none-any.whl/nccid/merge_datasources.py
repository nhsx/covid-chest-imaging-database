from pathlib import Path
from typing import Dict, List

import pandas as pd
from pydicom.dataset import Dataset
from tqdm.auto import tqdm

from nccid.etl import ingest_dicom_json


def patients_data_dicom_update(
    patients_df: pd.DataFrame, files: List[Path]
) -> pd.DataFrame:
    """
    Fills in missing values for Sex and Age from xray dicom headers.
    """

    def _demographics_from_dicom(dicom_header: Dataset) -> Dict[str, any]:

        extracted_data = {
            "PatientSex": dicom_header["PatientSex"].value,
            "PatientAge": dicom_header["PatientAge"].value,
        }
        return extracted_data

    def _fill_sex(x: pd.Series, df_dicom: pd.DataFrame) -> str:

        sex = x["sex"]
        if sex == "Unknown":
            try:
                sex = df_dicom.loc[x["Pseudonym"]]["PatientSex"]
            except KeyError:
                print(f'Pseudonym not in df_dicom data: {x["Pseudonym"]}')

        return sex if sex.lower() in ["f", "m", "unknown"] else "Unknown"

    def _fill_age(x: pd.Series, df_dicom: pd.DataFrame) -> int:

        age = x["age"]
        if pd.isnull(age):
            try:
                age = int(
                    "".join(
                        filter(str.isdigit, df_dicom.loc[x["Pseudonym"]]["PatientAge"])
                    )
                )
            except KeyError:
                print(f'Pseudonym not in df_dicom data: {x["Pseudonym"]}')

        return age

    all_data = {}
    for file in tqdm(files, desc="Reading files"):
        dicom_header = ingest_dicom_json(file)
        patient_id = dicom_header["PatientID"].value
        if patient_id not in all_data:
            dicom_data = _demographics_from_dicom(dicom_header)
            all_data[patient_id] = dicom_data
    df_dicom = pd.DataFrame(all_data).T

    patients_df["sex_update"] = patients_df.apply(
        lambda x: _fill_sex(x, df_dicom), axis=1
    )
    patients_df["age_update"] = patients_df.apply(
        lambda x: _fill_age(x, df_dicom), axis=1
    )

    return patients_df
