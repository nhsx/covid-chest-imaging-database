"""Plotting functions"""

from pathlib import Path
from typing import Optional
import pandas as pd

from IPython.display import display
from kaleido.scopes.plotly import PlotlyScope
import plotly

SCOPE = PlotlyScope()


def save(figure, title: Optional[str] = None, save_path: Optional[Path] = None) -> None:
    """Save a given figure."""
    if title is None:
        # generate automatic title
        title = (
            figure.layout["title"]["text"] or figure.layout["annotations"][0]["text"]
        )
    if save_path is None:
        save_path = f"../plots/{title}.png"

    with open(save_path, "wb") as f:
        f.write(SCOPE.transform(figure, format="png"))


def plot_and_save(
    figure, title: Optional[str] = None, save_path: Optional[Path] = None
) -> None:
    """Display and then save a given figure."""
    display(figure)
    save(figure, title, save_path)


def suppressed_bar_plot(
    df: pd.DataFrame, threshold: int = 7, percentage: bool = False
) -> plotly.graph_objs._figure.Figure:
    """
    Function to render suppressed bar plots.
    Suppression of data is indicated with an * annotation above the bar.
    If no values are below the threshold then an unannotated bar plot is returned.
    """

    # suppress data
    df[df < threshold] = 0
    suppression_df = df < threshold

    # annotation parameters
    N_series = df.shape[1]
    total_width = 0.8
    star_height = df.max().max() * 0.05
    if percentage:
        df = df * 100 / df.sum(axis=0)
        star_height = 2.5

    # generate annotations and annotation locations
    annotation_locs = []
    for row_loc, row in enumerate(suppression_df.values):
        if any(row):
            col_locs = [i for i, x in enumerate(row) if x]
            # current implementation doesn't scale well to more than 2 series.
            # need to figure out right algorithm to fix this
            locs = [
                row_loc + total_width * (1 + 2 * col_loc - N_series) / (2 * N_series)
                for col_loc in col_locs
            ]
            annotation_locs = annotation_locs + locs

    annotations = [
        dict(x=loc, y=star_height, text="*", showarrow=False, size=20, alpha=1.0)
        for loc in annotation_locs
    ]

    # plotting
    if suppression_df.sum().sum() > 0:
        fig = df.iplot(
            kind="bar",
            dimensions=(1000, 600),
            annotations=annotations,
            asFigure=True,
        ).add_annotation(
            xref="paper",
            yref="paper",
            xshift=-420,
            xanchor="left",
            yshift=250,
            yanchor="top",
            text="* indicates supressed data",
            showarrow=False,
            font=dict(size=14),
        )
        return fig
    else:  # return without annotations if nothing suppressed
        fig = df.iplot(
            kind="bar",
            dimensions=(1000, 600),
            asFigure=True,
        )
        return fig
